#include <cs50.h>
#include <stdio.h>

int main(void)
{
    //prompt user to input a hight
    int h;
    do
    {
        h = get_int("Height of the piramid: ");
    }
    while (h < 1 || h > 8);
    
    
    //building the piramid
    
    for (int i = 0; i < h; i++)
    {
        for (int w = h - 1; w > i; w--)
        {
            //to print
            printf(" ");
        }
        
        for (int r = -1; r < i; r++)
        {
            printf("#");
        }
        printf("\n");
    }
    
     
   
}